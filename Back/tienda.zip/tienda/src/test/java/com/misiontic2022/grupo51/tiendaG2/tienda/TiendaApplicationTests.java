package com.misiontic2022.grupo51.tiendaG2.tienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
